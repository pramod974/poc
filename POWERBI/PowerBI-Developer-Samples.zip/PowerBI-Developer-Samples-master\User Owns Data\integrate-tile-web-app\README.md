# Source code for integrate a tile into an app walkthrough
Integrate a Power BI tile enables application developers to integrate Power BI tiles from a user's power BI account by embedding an IFrame into an app, such as a mobile app or web app.

See [Integrate a tile into an app walkthrough](https://powerbi.microsoft.com/en-us/documentation/powerbi-developer-integrate-tile).
