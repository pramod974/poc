# Integrate a dashboard into an app
Integrate a Power BI dashboard enables application developers to integrate Power BI dashboards from a user's power BI account by embedding an IFrame into an app, such as a mobile app or web app.

A documentation for how to run this sample is coming soon. You can follow instructions for report/tile samples for now. To learn how to run this sample, see [Integrate a Power BI tile or report into an app](https://powerbi.microsoft.com/en-us/documentation/powerbi-developer-integrate-a-power-bi-tile-or-report/).

