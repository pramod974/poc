const config = {
  version: '2.6.1',
  type: 'js'
};

export default config;